<?php
    $db=new mysqli("localhost","root","","upload");
    if($db->connect_error){
        echo "数据库连接错误".$db->connect_error;
        exit;
    }
    $db->query('set names utf8');
    $dizhi=$_REQUEST['dizhi'];
    $sql="insert into upload(text) VALUES ('$dizhi')";
    $result=$db->query($sql);
    if($result){
        echo '提交成功';
        echo $dizhi;
    }else{
        echo '提交失败';
    }
    echo $dizhi;
?>